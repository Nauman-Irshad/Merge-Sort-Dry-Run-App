package com.example.merge_sort;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private EditText inputArray;
    private Button sortButton, resetButton;
    private LinearLayout visualizationLayout;

    // Stores all the steps of the merge sort algorithm for visualization
    private ArrayList<String> steps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputArray = findViewById(R.id.inputArray);
        sortButton = findViewById(R.id.sortButton);
        resetButton = findViewById(R.id.resetButton);
        visualizationLayout = findViewById(R.id.visualizationLayout);

        // Sort Button Click Listener
        sortButton.setOnClickListener(v -> {
            String input = inputArray.getText().toString().trim();

            if (input.isEmpty()) {
                Toast.makeText(this, "Please enter numbers separated by commas.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String[] numbers = input.split(",");
                int[] array = new int[numbers.length];

                for (int i = 0; i < numbers.length; i++) {
                    if (!numbers[i].matches("-?\\d+")) {
                        Toast.makeText(this, "Invalid input. Please enter numbers only.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    array[i] = Integer.parseInt(numbers[i]);
                }

                // Clear previous steps and views
                steps.clear();
                visualizationLayout.removeAllViews();
                mergeSort(array);

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid input. Please enter numbers separated by commas.", Toast.LENGTH_SHORT).show();
            }
        });

        // Reset Button Click Listener
        resetButton.setOnClickListener(v -> {
            inputArray.setText("");
            visualizationLayout.removeAllViews();
            steps.clear();
        });
    }

    // Merge Sort Implementation
    private void mergeSort(int[] array) {
        if (array.length < 2) return;

        int mid = array.length / 2;
        int[] left = Arrays.copyOfRange(array, 0, mid);
        int[] right = Arrays.copyOfRange(array, mid, array.length);

        // Add visualization for dividing arrays with animation
        addStepVisualization("Dividing: " + Arrays.toString(array));

        mergeSort(left);
        mergeSort(right);

        merge(array, left, right);
    }

    // Merging two sorted subarrays
    private void merge(int[] array, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;

        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                array[k++] = left[i++];
            } else {
                array[k++] = right[j++];
            }
        }

        while (i < left.length) {
            array[k++] = left[i++];
        }

        while (j < right.length) {
            array[k++] = right[j++];
        }

        // Add visualization for merging arrays with animation
        addStepVisualization("Merging: " + Arrays.toString(array));
    }

    // Method to add the step visualization to the UI
    private void addStepVisualization(String step) {
        // Add the current step to the steps list
        steps.add(step);

        // Create a TextView for the step description
        TextView description = new TextView(this);
        description.setText(step);
        description.setTextSize(16);
        description.setTextColor(getResources().getColor(android.R.color.black));
        description.setPadding(8, 16, 8, 8);
        visualizationLayout.addView(description);

        // Create a horizontal layout for array visualization
        LinearLayout arrayLayout = new LinearLayout(this);
        arrayLayout.setOrientation(LinearLayout.HORIZONTAL);
        arrayLayout.setPadding(8, 8, 8, 8);

        // Loop through the array and display the values
        ArrayList<TextView> boxes = new ArrayList<>();

        for (String value : step.split(":")[1].split(",")) {
            TextView box = new TextView(this);
            box.setText(value.trim());
            box.setTextSize(18);
            box.setTextColor(getResources().getColor(android.R.color.white));
            box.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
            box.setPadding(16, 16, 16, 16);
            arrayLayout.addView(box);
            boxes.add(box);
        }

        // Add the array layout to the main visualization layout
        visualizationLayout.addView(arrayLayout);

        // Add Animation: Translate each array element
        for (int i = 0; i < boxes.size(); i++) {
            animateElement(boxes.get(i), i * 100); // Animate each element with a delay
        }
    }

    // Method to animate the element with a translation effect
    private void animateElement(TextView element, int delay) {
        // Create a translation animation (move the element horizontally)
        ObjectAnimator translationX = ObjectAnimator.ofFloat(element, "translationX", 500f, 0f);
        translationX.setStartDelay(delay);  // Set the delay for each element to create staggered animations
        translationX.setDuration(500);  // Duration of the animation
        translationX.start();

        // Add scaling effect to make it appear like the element grows/shrinks
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(element, "scaleX", 0.5f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(element, "scaleY", 0.5f, 1f);
        scaleX.setStartDelay(delay);
        scaleY.setStartDelay(delay);
        scaleX.setDuration(500);
        scaleY.setDuration(500);
        scaleX.start();
        scaleY.start();

        // Add rotation effect
        ObjectAnimator rotation = ObjectAnimator.ofFloat(element, "rotation", 0f, 360f);
        rotation.setStartDelay(delay);
        rotation.setDuration(500);
        rotation.start();

        // Add fade-in effect
        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(element, "alpha", 0f, 1f);
        fadeIn.setStartDelay(delay);
        fadeIn.setDuration(500);
        fadeIn.start();
    }
}
